import{j as a,b as n}from"./Card-BtsPFY12.js";function t({className:e,...r}){return a.jsx("div",{"aria-hidden":"true",className:n("animate-pulse rounded-md bg-border/60",e),...r})}export{t as S};
