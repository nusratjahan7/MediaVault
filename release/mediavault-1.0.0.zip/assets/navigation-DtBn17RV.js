function c(t,r){try{const e=new URL(chrome.runtime.getURL(t));for(const[o,n]of Object.entries(r??{}))e.searchParams.set(o,String(n));chrome.tabs.create({url:e.toString()})}catch{}}export{c as o};
