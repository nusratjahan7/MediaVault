import{c as a}from"./Card-BwviRcwI.js";import{a as s}from"./id-CQYzvhgC.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=a("Upload",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]]),m=/^[^\s/\\?#]{1,80}$/u;function c(e){return e.trim().replace(/^@+/,"")}function p(e,o){const t=encodeURIComponent(c(o));return e==="instagram"?`https://www.instagram.com/${t}/`:e==="facebook"?`https://www.facebook.com/${t}/`:`https://www.tiktok.com/@${t}`}function f(e,o){try{const t=new URL(o);if(!/^https?:$/.test(t.protocol))return null;const r=t.hostname.toLowerCase();return s[e].hostnames.some(n=>r===n||r.endsWith(`.${n}`))?t.toString():null}catch{return null}}async function h(e){return typeof e.text=="function"?e.text():new Promise((o,t)=>{const r=new FileReader;r.onerror=()=>t(new Error("The selected file could not be read.")),r.onload=()=>o(String(r.result??"")),r.readAsText(e)})}export{m as P,d as U,p as d,c as n,f as p,h as r};
