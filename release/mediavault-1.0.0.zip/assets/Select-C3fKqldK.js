import{c as n,j as e,b as t}from"./Card-BtsPFY12.js";import{C as c}from"./chevron-down-B_VCGprt.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=n("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]);function l({className:r,wrapperClassName:o,children:s,...a}){return e.jsxs("div",{className:t("relative",o),children:[e.jsx("select",{className:t("h-9 w-full appearance-none rounded-md border border-border bg-surface px-3 pr-8 text-sm text-fg transition-colors focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20",r),...a,children:s}),e.jsx(c,{className:"pointer-events-none absolute top-1/2 right-2.5 size-3.5 -translate-y-1/2 text-muted","aria-hidden":"true"})]})}export{l as S,u as V};
