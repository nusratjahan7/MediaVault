import{c as a,j as e,a as l,b as d}from"./Card-BtsPFY12.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=a("RotateCw",[["path",{d:"M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",key:"1p45f6"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=a("TriangleAlert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);function h({title:s="Something went wrong",description:r,onRetry:t,retryLabel:n="Try again",className:i,compact:c=!1}){return e.jsxs("div",{role:"alert",className:d("flex flex-col items-center justify-center text-center",c?"px-4 py-6":"px-6 py-10",i),children:[e.jsx("div",{className:"mb-3 flex size-10 items-center justify-center rounded-lg bg-danger/10 text-danger",children:e.jsx(m,{className:"size-5","aria-hidden":"true"})}),e.jsx("h2",{className:"text-sm font-semibold tracking-tight text-fg",children:s}),e.jsx("p",{className:"mt-1.5 max-w-[40ch] text-xs leading-relaxed text-muted",children:r}),t&&e.jsx(l,{variant:"secondary",size:"sm",className:"mt-4",onClick:t,icon:e.jsx(x,{className:"size-3.5","aria-hidden":"true"}),children:n})]})}export{h as E,m as T};
